# -*- coding: utf-8 -*-
import sys,os,urllib2,re
current_dir = os.path.dirname(os.path.realpath(__file__))
basename = os.path.basename(current_dir)
core_dir =  current_dir.replace(basename,'').replace('parsers','')
sys.path.append(core_dir)
from peertopeerutils.webutils import *
from peertopeerutils.pluginxbmc import *
from peertopeerutils.directoryhandle import *
from BeautifulSoup import BeautifulSoup
import acestream as ace
import sopcast as sop

def module_tree(name,url,iconimage,mode,parser,parserfunction):
	if not parserfunction:
		show_list_match()
	elif parserfunction == 'show_link':
		show_link(url)

def send_request(url):
	request = urllib2.Request(url)
	request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:37.0) Gecko/20100101 Firefox/37.0')
	request.add_header('Referer', 'http://tructiepbongda.com/')
	request = urllib2.urlopen(request)
	html = request.read()
	request.close()
	
	return html
		
def show_list_match():
	html = send_request('http://tructiepbongda.com/')
	soup = BeautifulSoup(html)
	
	matchs = soup.find('div', 'listmatch')
	if matchs:
		mLink = matchs.findAll('div', 'livelink')
		mTime = matchs.findAll('div', 'matchtime')
		mName = matchs.findAll('div', 'matchtitle')
		
		for i in range(len(mName)):
			addDir('[' + mTime[i].find('p').text.encode('utf-8')
				+ '-' + mTime[i].find('b').text.encode('utf-8') + '] '
				+ mName[i].text.encode('utf-8').replace('&amp;','&'),
				mLink[i].find('a').get('href'),401,"",1,True,parser='tructiepbongda',parserfunction='show_link')
			
def show_link(url):
	html = send_request(url)
	soup = BeautifulSoup(html)
	
	links = soup.findAll('a', 'small-button')
	for link in soup.findAll('a', 'small-button'):
		if 'sop://' in link['href']:
			contentUrl = str(link.find('span').text.encode('utf-8')).replace('&#8211; ','').replace('Chất lượng HD ','')
			addDir('[Sopcast] ' + contentUrl,link['href'],1,"",1,False)
		if 'acestream://' in link['href']:
			contentUrl = str(link.find('span').text.encode('utf-8')).replace('&#8211; ','')
			addDir('[Acestream] ' + contentUrl,link['href'],1,"",1,False)
			
			
			
			
			
			
			
			
			
			
			